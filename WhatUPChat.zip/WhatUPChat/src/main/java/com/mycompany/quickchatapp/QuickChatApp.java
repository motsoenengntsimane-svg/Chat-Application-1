/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp;

/**
 *
 * @author motso
 */

import java.io.*;                             // Used to store byte stream salt info during registration to recall when logining
import java.util.ArrayList;                   // Used to store multiple users
import java.util.Scanner;                     // Used to read/obtain user input
import java.security.MessageDigest;           // Used to hash the password 
import java.security.NoSuchAlgorithmException;// Used in the case a method is not found in a class 
import java.security.SecureRandom;            // generates a cryptographic secure random number 

public class QuickChatApp {

    // User class implements Serializable for file storage
    static class User implements Serializable {
        String username;
        String passwordHash;
        String cellphone;
        byte[] salt;

        User(String username, String passwordHash, String cellphone, byte[] salt) {
            this.username = username;
            this.passwordHash = passwordHash;
            this.cellphone = cellphone;
            this.salt = salt;
        }
    }

    private static final String DATA_FILE = "users.dat";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Load users from file
        ArrayList<User> users = loadUsers();   // store multiple users 

        System.out.println("\nWelcome to QuickChatApp!");

        while (true) {
            //Creating a menu with 3 options
            System.out.println("\nMain Menu");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> registerUser(scanner, users);
                case 2 -> loginUser(scanner, users);
                case 3 -> {
                    saveUsers(users); // Save before exiting
                    System.out.println("Existing QuickChatApp. Goodbye!");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    
    private static void registerUser(Scanner scanner, ArrayList<User> users) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.println("Username successfully captured.");

        if (!(username.contains("_") && username.length() <= 5)) {
            System.out.println("Username is not correctly formated, it must contain at least one underscore (_) and be at most 5 characters long.");
            return;
        }
        //Verifying if user already exists
        for (User user : users) {
            if (user.username.equals(username)) {
                System.out.println(" Username already exists. Please choose another.");
                return;
            }
        }

        System.out.print("Enter South African cellphone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.println("Cellphone number successfully added");
        String saPhoneRegex = "^(?:\\+27|27|0)(6\\d|7\\d|8\\d)\\d{7}$";     // using a regex to match a specific sequence/pattern of numbers for a SA cellphone number
        if (!phoneNumber.matches(saPhoneRegex)) {
            System.out.println("Incorrectly formatted South African Cellphone Number. Example: 0821234567 or +27821234567");
            return;
        }

        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.println("Password successfully captured");
        if (!password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
            System.out.println(" Password must be at least 8 characters long, contain 1 uppercase letter, 1 number, and 1 special character.");
            return;
        }
        //Using a salt and hash to better protect the password 
        byte[] salt = getSalt();
        String hashedPassword = hashPassword(password, salt);

        users.add(new User(username, hashedPassword, phoneNumber, salt));
        saveUsers(users); // Save immediately after registration

        System.out.println(" Registration successful for user: " + username);
        System.out.println(" Registered cellphone: " + phoneNumber);
    }

    // Login method (username or cellphone and password)
    private static void loginUser(Scanner scanner, ArrayList<User> users) {
        System.out.print("Enter username or cellphone: ");
        String loginInput = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        for (User user : users) {
            if (user.username.equals(loginInput) || user.cellphone.equals(loginInput)) {  //check if the login input is the same as the user input captured during the registration Method//
                String hashedPassword = hashPassword(password, user.salt);                                
                if (user.passwordHash.equals(hashedPassword)) {
                    System.out.println(" Login successful! Welcome, " + user.username + "great to see you again.");
                    return;
                }
            }
        }
        System.out.println("Username/Cellphone or password incorrect, please try again.");
    }

    // Password hashing with salt
    private static String hashPassword(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedBytes = md.digest(password.getBytes());

            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    // Generate random salt
    private static byte[] getSalt() {
        SecureRandom sr = new SecureRandom();
        byte[] salt = new byte[16];
        sr.nextBytes(salt);
        return salt;
    }

    // Save users to file
    private static void saveUsers(ArrayList<User> users) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(users);
        } catch (IOException e) {
            System.out.println(" Error saving users: " + e.getMessage());
        }
    }

    // Load users from file
    @SuppressWarnings("unchecked")
    private static ArrayList<User> loadUsers() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (ArrayList<User>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(" Error loading users: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
