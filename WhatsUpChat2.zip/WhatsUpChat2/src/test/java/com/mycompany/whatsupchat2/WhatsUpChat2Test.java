/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.whatsupchat2;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WhatsUpChat2Test {



    // Test message length validation
    @Test
    public void testMessageLength() {
        String msg = "Short message under 250 characters.";
        assertTrue(msg.length() <= 250,
                "Message ready to send");
    }

    @Test
    public void testMessageLengthInvalid() {
        String longMsg = "a".repeat(300);
        assertFalse(longMsg.length() <= 250,
                "Message exceeds 250 chars by" + (longMsg.length() - 250) + " please reduce size");
    }

    // Test recipient number validation
    @Test
    public void testRecipientNumberValid() {
        String recipient = "+27831234567";
        assertTrue(recipient.matches("^\\+27[6-8]\\d{8}$"),
                "Cellphone number successfully captured.");
    }

    @Test
    public void testRecipientNumberInvalid() {
        String recipient = "+27123456789";
        assertFalse(recipient.matches("^\\+27[6-8]\\d{8}$"),
                "Cellphone number is incorrectly formated or does not contain an international code. Please correct the number and try again.");
    }

   
    
    /**
     * Test of generateMessageID method, of class WhatsUpChat2.
     */
    @Test
    public void testGenerateMessageID() {
        System.out.println("generateMessageID");
        WhatsUpChat2.generateMessageID();    
    }

    /**
     * Test of generateMessageHash method, of class WhatsUpChat2.
     */
    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String id = WhatsUpChat2.generateMessageID();
        Integer num = 0;
        String msg = "Hi Mike, can you join us for dinner tonight?";
        String expResult = "00:0:HITONIGHT";//I do not understand how the first two digits of the id are supposed to be 00 when the the id is randomly generated.
        String result = WhatsUpChat2.generateMessageHash(id, num, msg);
        assertEquals(expResult, result);
        
    }
    
    /**
     * Test of messageActions method, of class WhatsUpChat2.
     */
      @Test
    void testMessageActions() {
        // Initialize the array of actions
        String[] actions = {"send message", "disregard message", "store message"};

        // Expected system responses for each action
        ArrayList<String> expectedResponses = new ArrayList<>();
        expectedResponses.add("Message successfully sent.");
        expectedResponses.add("Press 0 to delete the message.");
        expectedResponses.add("Message successfully stored.");

        // Simulate system behavior based on action selection
        ArrayList<String> actualResponses = new ArrayList<>();
        for (String action : actions) {
            switch (action.toLowerCase()) {
                case "send message" -> actualResponses.add("Message successfully sent.");
                case "disregard message" -> actualResponses.add("Press 0 to delete the message.");
                case "store message" -> actualResponses.add("Message successfully stored.");
                default -> actualResponses.add("Invalid action.");
            }
        }

        // Assertions
        assertEquals(expectedResponses.size(), actualResponses.size(), "Response count should match action count");
        for (int i = 0; i < actions.length; i++) {
            assertEquals(expectedResponses.get(i), actualResponses.get(i),
                    "Response should match expected output for action: " + actions[i]);
        }
    }
}
    





