/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.whatupchat3;

import java.util.ArrayList;
import java.util.Random;
import java.io.IOException;
import java.io.FileWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author motso
 */
public class WhatUpChat3 {

    //Registered user information
    static String registeredUsername;
    static String registeredPhone;
    static String registeredPassword;

    //Message counter
    static int totalMessagesSent = 0;
    static int messageNumber = 0;
    
    // === Message Data storage ( from Part3 MessageManager) ===
    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();
    
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to WhatUpChat!");
        registerUser();
        
        if(loginUser()) {
        JOptionPane.showMessageDialog(null, "Login successfull. Redirecting to WhatUpChat.");
        runMainMenu();
        }else{
            JOptionPane.showMessageDialog(null, "Login failed. Exiting WhatUpChat.");
        }
        }
     public static void registerUser() {
        boolean valid = false;

        while (!valid) {
            // Validate username
            registeredUsername = JOptionPane.showInputDialog("Create a username (must contain an underscore and should not exceed 5 chars long).");
            if (!(registeredUsername.contains("_") && registeredUsername.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue;
            }

            // Validate password
            registeredPassword = JOptionPane.showInputDialog("Create password (must be >8 chars, include a capital letter, number, and special char).");
            if (!registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^+]).{8,}$")) {
                JOptionPane.showMessageDialog(null, "Invalid password.");
                continue;
            }

            // Validate cellphone number
            registeredPhone = JOptionPane.showInputDialog("Enter phone number (+27xxxxxxxxx):");
            if (!registeredPhone.matches("^\\+27[6-8]\\d{8}$")) {
                JOptionPane.showMessageDialog(null, "Invalid phone number.");
                continue;
            }

            JOptionPane.showMessageDialog(null, "Registration successful!");
            valid = true;
        }
    }
     //Check login details against registered ones
      public static boolean loginUser() {
        String user = JOptionPane.showInputDialog("Login - Enter your username:");
        String pass = JOptionPane.showInputDialog("Enter your password:");

        return user != null && pass != null && user.equals(registeredUsername) && pass.equals(registeredPassword);
    }
      //Main menu with Message system + Message Manager options
      public static void runMainMenu() {
          boolean keepRunning = true;
          
          while (keepRunning) {
              String[] options = {
                  "Send Messsages",
                  "Message Manager",
                  "Quit"
              };
              int choice = JOptionPane.showOptionDialog(null, "Choose an option: ", "Main Menu",
                      JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
              
              switch (choice) {
                  case 0 -> sendMessages();
                  case 1 -> messageManagerMenu();
                  case 2, JOptionPane.CLOSED_OPTION -> {
                      keepRunning = false;
                      JOptionPane.showMessageDialog(null, "Goodbye");
                  }
                  default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
              }
          }
      }
      
      //Send messages interface (from code 1), now also stores in array (code 2)
      public static void sendMessages() {
          String inputCount = JOptionPane.showInputDialog("How many messages would you like to send?");
          if (inputCount == null) return;
          int count;
          try {
              count = Integer.parseInt(inputCount);
          } catch (NumberFormatException e) {
              JOptionPane.showMessageDialog(null, "Invalid number.");
              return;
          }
          
          for (int i = 0; i < count; i++) {
              messageNumber++;
              String messageID = generateMessageID();
              
              String recipient = JOptionPane.showInputDialog("Enter recipient number(+27xxxxxxxxx):");
              if (recipient == null || !recipient.matches("^\\+27\\d{9}$")) {
                  JOptionPane.showMessageDialog(null, "Invalid number Format");
                  i--;
                  continue;
                  
      }
              //Limit message characters to 250
              String message = JOptionPane.showInputDialog("Enter message (max 250 chars):");
              if (message == null) {
                  i--;
                  continue;
              }
              if (message.length() > 250) {
                    JOptionPane.showMessageDialog(null,"Message too long by" + (message.length() - 250) + "characters");
                    i--;
                    continue;
                }
                 String hash = generateMessageHash(messageID, messageNumber, message);
                
                //Allow user to choose what to do with the message
                String[] actions = {"Send message", "Disregard message", "Store message"};
                Integer action = JOptionPane.showOptionDialog(null,"What do you want to do?", "Message Options",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);
                
                switch (action) {
                    case 0 -> {
                        totalMessagesSent++;
                        //Add to sent message arrays
                        sentMessages.add(message);
                        recipients.add(recipient);
                        messageIDs.add(messageID);
                        messageHashes.add(hash);
                        
                        displayMessageDetails(messageID, hash, recipient, message);
                        JOptionPane.showMessageDialog(null, "Message successfully sent.");
                    }
                    case 1 -> {
                        disregardedMessages.add(message);
                        JOptionPane.showMessageDialog(null, "Message disregarded");
                    }
                    case 2 -> {
                        storedMessages.add("Recipient: " + recipient + " | Message: " + message);
                        writeMessageToJSON(messageID, hash, recipient, message);
                        JOptionPane.showMessageDialog(null, "Message successfully stored.");
                    }
                    default -> {
                        JOptionPane.showMessageDialog(null, "No action taken.");
                        i--;
                    }
                  }
              }
          JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
          
          }
      // === Message Manager menu with a GUI equivalents methods ===
      public static void messageManagerMenu() {
          boolean running = true;
          while (running) {
              String[] options = {
                  "Display all sent messages.",
                  "Display longest sent message.",
                  "Search by Message ID.",
                  "Search message by recipient.",
                  "Delete message by hash.",
                  "Show full report.",
                  "Back to main menu."
              };
             int choice = JOptionPane.showOptionDialog(null, "Message manager options: ", "Message Manager",
                     JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
            switch (choice) {
                case 0 -> displaySendersAndRecipients();
                case 1 -> displayLongestMessage();
                case 2 -> {
                    String id = JOptionPane.showInputDialog("Enter Message ID: ");
                    if (id != null) searchByMessageID(id);
                }
                case 3 -> {
                    String recipient = JOptionPane.showInputDialog("Enter Recipient Number: ");
                    if (recipient != null) searchByRecipient(recipient);
                }
                case 4 -> {
                    String hash = JOptionPane.showInputDialog("Enter Message Hash: ");
                    if (hash != null) deleteByMessageHash(hash);
                }
                case 5 -> displayReport();
                case 6, JOptionPane.CLOSED_OPTION -> running = false;
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
                }
              }
          }
      // === Message Manager methods ===
      public static void displaySendersAndRecipients() {
          if (sentMessages.isEmpty()) {
              JOptionPane.showMessageDialog(null, "No sent messages to display.");
              return;
          }
          StringBuilder sb = new StringBuilder();
          for (int i = 0; i < sentMessages.size(); i++) {
              sb.append("Recipient: ").append(recipients.get(i)).append("\n");
              sb.append("Message: ").append(sentMessages.get(i)).append("\n");
              sb.append("Hash: ").append(messageHashes.get(i)).append("\n");
              sb.append("MessageID: ").append(messageIDs.get(i)).append("\n");
              sb.append("---------------------------\n");
          }
          JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
      }
      public static void displayLongestMessage() {
          if (sentMessages.isEmpty()) {
              JOptionPane.showMessageDialog(null, "No sent messages.");
              return;
          }
          String longest = "";
          for (String msg : sentMessages) {
              if (msg.length() > longest.length()) {
                  longest = msg;
              }
          }
          JOptionPane.showMessageDialog(null, "Longest Sent Message:\n" + longest);
      }
      public static void searchByMessageID(String id) {
          for (int i = 0; i < messageIDs.size(); i++) {
              if (messageIDs.get(i).equals(id)) {
                  String msgDetails = "Recipient: " + recipients.get(i) + "\nMessage: " + sentMessages.get(i);
                  JOptionPane.showMessageDialog(null, msgDetails, "Search Result", JOptionPane.INFORMATION_MESSAGE);
                  return;
              }
          }
          JOptionPane.showMessageDialog(null, "Message ID not found.");
      }
      
      public static void searchByRecipient(String recipientNumber){
          StringBuilder sb = new StringBuilder("Messages to " + recipientNumber + ":\n");
          boolean found = false;
          for (int i = 0; i < recipients.size(); i++) {
              if (recipients.get(i).equals(recipientNumber)) {
                  sb.append(sentMessages.get(i)).append("\n");
                  found = true;
              }
          }
          for (String stored :  storedMessages) {
              if ( stored.contains(recipientNumber)) {
                  sb.append(stored).append("\n");
                  found = true;
              }
          }
          
              
          if (!found) {
              JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipientNumber);
          } else {
              JOptionPane.showMessageDialog(null, sb.toString(), "Messages by recipient ", JOptionPane.INFORMATION_MESSAGE);
          }
      }
      public static void deleteByMessageHash(String hash) {
          for (int i = 0; i < messageHashes.size(); i++) {
              if (messageHashes.get(i).equals(hash)) {
                  String msg = sentMessages.get(i);
                  sentMessages.remove(i);
                  recipients.remove(i);
                  messageIDs.remove(i);
                  messageHashes.remove(i);
                  JOptionPane.showMessageDialog(null, "Deleted message:\n" + msg);
                  return;
              }
          }
          JOptionPane.showMessageDialog(null, "Message hash not found.");
      }
      
      public static void displayReport() {
          if (sentMessages.isEmpty()) {
          JOptionPane.showMessageDialog(null, "No sent messages to report.");
          return;
          }
          StringBuilder sb = new StringBuilder("===== SENT MESSAGE REPORT =====\n");
          for (int i = 0; i< sentMessages.size(); i++) {
              sb.append("Message ID: ").append(messageIDs.get(i)).append("\n");
              sb.append("Message hash: ").append(messageHashes.get(i)).append("\n");
              sb.append("Recipient: ").append(recipients.get(i)).append("\n");
              sb.append("Message: ").append(sentMessages.get(i)).append("\n");
              sb.append("-----------------------------\n");
          }
          JOptionPane.showMessageDialog(null, sb.toString(), "Message Report.", JOptionPane.INFORMATION_MESSAGE);
      }
      // === Helper methods from Code1 ===
      public static String generateMessageID() {
          return String.format("%010d", new Random().nextInt(1_000_000_000));
      }
      
      public static String generateMessageHash(String id, int num, String msg) {
          String[] words = msg.trim().split(" ");
          String first = words.length > 0 ? words[0] : "";
          String last = words.length >1 ? words[words.length - 1] : "";
          return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
      }
      
      public static void displayMessageDetails(String id, String hash, String recipient, String message) {
          JOptionPane.showMessageDialog(null,
                  "Message ID: " + id +
                          "\nHash: " + hash +
                          "\nRecipient: " + recipient +
                          "\nMessage: " + message);
      }
      public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
          StringBuilder jsonEntry = new StringBuilder();
          jsonEntry.append("{\n");
          jsonEntry.append(" \"MessageID\": \"").append(messageID).append("\",\n");
          jsonEntry.append(" \"MessageHash\": \"").append("\",\n");
          jsonEntry.append(" \"Recipient\": \"").append("\",\n");
          jsonEntry.append(" \"Message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
          jsonEntry.append("},\n");
          
          try (FileWriter file = new FileWriter("jsonnew.json", true)) { //append mode
              file.write(jsonEntry.toString());
          } catch (IOException e) {
              JOptionPane.showMessageDialog(null, "Error writing file: "  + e.getMessage());
          }
                  
          }
      }
      



