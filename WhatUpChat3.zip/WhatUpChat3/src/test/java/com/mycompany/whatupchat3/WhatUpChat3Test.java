/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.whatupchat3;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.*;

public class WhatUpChat3Test {
    

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        // Clear any previous data
        WhatUpChat3.sentMessages.clear();

        // Developer test data (messages 1–4)
        List<String> testMessages = Arrays.asList(
            "Did you get the cake?",
            "Where are you? You are late! I have asked you to be on time.",
            "Ok, I am leaving without you.",
            "It’s dinner time!"
        );

        // Simulate sending messages
        WhatUpChat3.sentMessages.addAll(testMessages);

        // Verify array contains expected messages
        assertEquals("Did you get the cake?", WhatUpChat3.sentMessages.get(0));
        assertEquals("It’s dinner time!", WhatUpChat3.sentMessages.get(3));

        // Verify total count matches expected
        assertEquals(4, WhatUpChat3.sentMessages.size());
    }


    @Test
    public void testDisplaySendersAndRecipients() {
        WhatUpChat3.sentMessages.clear();
        WhatUpChat3.recipients.clear();
        WhatUpChat3.messageIDs.clear();
        WhatUpChat3.messageHashes.clear();

        WhatUpChat3.sentMessages.add("Did you get the cake?");
        WhatUpChat3.recipients.add("+27838884567");
        WhatUpChat3.messageIDs.add("MSG1");
        WhatUpChat3.messageHashes.add("HASH1");

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < WhatUpChat3.sentMessages.size(); i++) {
            sb.append("Recipient: ").append(WhatUpChat3.recipients.get(i)).append("\n");
            sb.append("Message: ").append(WhatUpChat3.sentMessages.get(i)).append("\n");
            sb.append("Hash: ").append(WhatUpChat3.messageHashes.get(i)).append("\n");
            sb.append("MessageID: ").append(WhatUpChat3.messageIDs.get(i)).append("\n");
        }

        assertTrue(sb.toString().contains("Recipient: +27838884567"));
        assertTrue(sb.toString().contains("Message: Did you get the cake?"));
    }

    @Test
    public void testDisplayLongestMessage() {
        WhatUpChat3.sentMessages.clear();
        WhatUpChat3.sentMessages.addAll(Arrays.asList(
            "Did you get the cake?",
            "Where are you? You are late! I have asked you to be on time.",
            "Ok, I am leaving without you.",
            "It’s dinner time!"
        ));

        String longest = "";
        for (String msg : WhatUpChat3.sentMessages) {
            if (msg.length() > longest.length()) longest = msg;
        }

        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }

    @Test
    public void testSearchByMessageID() {
        WhatUpChat3.sentMessages.clear();
        WhatUpChat3.messageIDs.clear();

        WhatUpChat3.sentMessages.add("It’s dinner time!");
        WhatUpChat3.messageIDs.add("MSG4");

        int index = WhatUpChat3.messageIDs.indexOf("MSG4");
        assertTrue(index >= 0);
        assertEquals("It’s dinner time!", WhatUpChat3.sentMessages.get(index));
    }

    @Test
    public void testSearchByRecipient() {
        WhatUpChat3.sentMessages.clear();
        WhatUpChat3.recipients.clear();

        WhatUpChat3.sentMessages.addAll(Arrays.asList(
            "Where are you? You are late! I have asked you to be on time.",
            "Ok, I am leaving without you."
        ));
        WhatUpChat3.recipients.addAll(Arrays.asList("+27838884567", "+27838884567"));

        List<String> found = new ArrayList<>();
        for (int i = 0; i < WhatUpChat3.recipients.size(); i++) {
            if (WhatUpChat3.recipients.get(i).equals("+27838884567")) {
                found.add(WhatUpChat3.sentMessages.get(i));
            }
        }

        assertTrue(found.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(found.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteByMessageHash() {
        WhatUpChat3.sentMessages.clear();
        WhatUpChat3.messageHashes.clear();
        WhatUpChat3.recipients.clear();
        WhatUpChat3.messageIDs.clear();

        WhatUpChat3.sentMessages.add("Where are you? You are late! I have asked you to be on time.");
        WhatUpChat3.messageHashes.add("HASH2");
        WhatUpChat3.recipients.add("+27838884567");
        WhatUpChat3.messageIDs.add("MSG2");

        assertTrue(WhatUpChat3.messageHashes.contains("HASH2"));
        WhatUpChat3.deleteByMessageHash("HASH2");
        assertFalse(WhatUpChat3.messageHashes.contains("HASH2"));
        assertFalse(WhatUpChat3.sentMessages.contains("Where are you? You are late! I have asked you to be on time."));
    }

    @Test
    public void testDisplayReport() {
        WhatUpChat3.sentMessages.clear();
        WhatUpChat3.messageIDs.clear();
        WhatUpChat3.messageHashes.clear();
        WhatUpChat3.recipients.clear();

        WhatUpChat3.sentMessages.add("Did you get the cake?");
        WhatUpChat3.messageIDs.add("MSG1");
        WhatUpChat3.messageHashes.add("HASH1");
        WhatUpChat3.recipients.add("+27838884567");

        StringBuilder report = new StringBuilder("===== SENT MESSAGE REPORT =====\n");
        for (int i = 0; i < WhatUpChat3.sentMessages.size(); i++) {
            report.append("Message ID: ").append(WhatUpChat3.messageIDs.get(i)).append("\n")
                  .append("Message hash: ").append(WhatUpChat3.messageHashes.get(i)).append("\n")
                  .append("Recipient: ").append(WhatUpChat3.recipients.get(i)).append("\n")
                  .append("Message: ").append(WhatUpChat3.sentMessages.get(i)).append("\n");
        }

        assertTrue(report.toString().contains("Message ID: MSG1"));
        assertTrue(report.toString().contains("Message hash: HASH1"));
    }
}
